package dao;

import entity.Employee;
import entity.Project;
import entity.Task;
import java.util.List;

public interface IProjectRepository {
    boolean createEmployee(Employee emp) throws Exception;
    boolean createProject(Project pj) throws Exception;
    boolean createTask(Task task) throws Exception;
    boolean assignProjectToEmployee(int projectId, int employeeId) throws Exception;
    boolean assignTaskInProjectToEmployee(int taskId, int projectId, int employeeId) throws Exception;
    boolean deleteEmployee(int employeeId) throws Exception;
    boolean deleteProject(int projectId) throws Exception;
    List getAllTasks(int employeeId, int projectId) throws Exception;
}