package dao;

import entity.Employee;
import entity.Project;
import entity.Task;
import exception.EmployeeNotFoundException;
import exception.ProjectNotFoundException;
import util.DBConnUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProjectRepositoryImpl implements IProjectRepository {

    public boolean createEmployee(Employee emp) throws Exception {
        String sql = "INSERT INTO Employee (id, name, designation, gender, salary, project_id) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, emp.getId());
            ps.setString(2, emp.getName());
            ps.setString(3, emp.getDesignation());
            ps.setString(4, emp.getGender());
            ps.setDouble(5, emp.getSalary());
            ps.setInt(6, emp.getProjectId());
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }

    @Override
    public boolean createProject(Project pj) throws Exception {
        String sql = "INSERT INTO Project (id, projectName, description, start_date, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pj.getId());
            ps.setString(2, pj.getProjectName());
            ps.setString(3, pj.getDescription());
            ps.setString(4, pj.getStartDate());
            ps.setString(5, pj.getStatus());
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }

    @Override
    public boolean createTask(Task task) throws Exception {
        String sql = "INSERT INTO Task (task_id, task_name, project_id, employee_id, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, task.getTaskId());
            ps.setString(2, task.getTaskName());
            ps.setInt(3, task.getProjectId());
            ps.setInt(4, task.getEmployeeId());
            ps.setString(5, task.getStatus());
            int rows = ps.executeUpdate();
            return rows > 0;
        }
    }

    @Override
    public boolean assignProjectToEmployee(int projectId, int employeeId) throws Exception {
        String sql = "UPDATE Employee SET project_id = ? WHERE id = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, projectId);
            ps.setInt(2, employeeId);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new EmployeeNotFoundException("Employee not found with ID: " + employeeId);
            return rows > 0;
        }
    }

    @Override
    public boolean assignTaskInProjectToEmployee(int taskId, int projectId, int employeeId) throws Exception {
        String sql = "UPDATE Task SET employee_id = ? WHERE task_id = ? AND project_id = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            ps.setInt(2, taskId);
            ps.setInt(3, projectId);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new ProjectNotFoundException("Task or Project not found");
            return rows > 0;
        }
    }

    @Override
    public boolean deleteEmployee(int employeeId) throws Exception {
        String sql = "DELETE FROM Employee WHERE id = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new EmployeeNotFoundException("Employee not found with ID: " + employeeId);
            return rows > 0;
        }
    }

    @Override
    public boolean deleteProject(int projectId) throws Exception {
        String sql = "DELETE FROM Project WHERE id = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, projectId);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new ProjectNotFoundException("Project not found with ID: " + projectId);
            return rows > 0;
        }
    }

    @Override
    public List getAllTasks(int employeeId, int projectId) throws Exception {
        String sql = "SELECT * FROM Task WHERE employee_id = ? AND project_id = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            ps.setInt(1, employeeId);
            ps.setInt(2, projectId);
            List tasks = new ArrayList<>();
            while (rs.next()) {
                Task task = new Task();
                task.setTaskId(rs.getInt("task_id"));
                task.setTaskName(rs.getString("task_name"));
                task.setProjectId(rs.getInt("project_id"));
                task.setEmployeeId(rs.getInt("employee_id"));
                task.setStatus(rs.getString("status"));
                tasks.add(task);
            }
            return tasks;
        }
    }
}