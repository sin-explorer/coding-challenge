package main;

import dao.ProjectRepositoryImpl;
import entity.Employee;
import entity.Project;
import entity.Task;
import exception.EmployeeNotFoundException;
import exception.ProjectNotFoundException;
import java.util.List;
import java.util.Scanner;
import util.DBConnUtil;
public class ProjectApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProjectRepositoryImpl repo = new ProjectRepositoryImpl();

        while (true) {
            System.out.println("\n=== Project Management System ===");
            System.out.println("1. Add Employee");
            System.out.println("2. Add Project");
            System.out.println("3. Add Task");
            System.out.println("4. Assign Project to Employee");
            System.out.println("5. Assign Task to Employee");
            System.out.println("6. Delete Employee");
            System.out.println("7. Delete Project");
            System.out.println("8. List All Tasks");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        // Add Employee
                        System.out.print("Enter Employee ID: ");
                        int empId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter Employee Name: ");
                        String empName = scanner.nextLine();
                        System.out.print("Enter Designation: ");
                        String designation = scanner.nextLine();
                        System.out.print("Enter Gender (M/F): ");
                        String gender = scanner.nextLine();
                        System.out.print("Enter Salary: ");
                        double salary = scanner.nextDouble();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter Project ID (0 if none): ");
                        int projectId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        Employee emp = new Employee(empId, empName, designation, gender, salary, projectId);
                        boolean empAdded = repo.createEmployee(emp);
                        System.out.println("Employee added: " + empAdded);
                        break;

                    case 2:
                        // Add Project
                        System.out.print("Enter Project ID: ");
                        int projId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter Project Name: ");
                        String projName = scanner.nextLine();
                        System.out.print("Enter Description: ");
                        String description = scanner.nextLine();
                        System.out.print("Enter Start Date (YYYY-MM-DD): ");
                        String startDate = scanner.nextLine();
                        System.out.print("Enter Status (started/dev/build/test/deployed): ");
                        String status = scanner.nextLine();

                        Project proj = new Project(projId, projName, description, startDate, status);
                        boolean projAdded = repo.createProject(proj);
                        System.out.println("Project added: " + projAdded);
                        break;

                    case 3:
                        // Add Task
                        System.out.print("Enter Task ID: ");
                        int taskId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter Task Name: ");
                        String taskName = scanner.nextLine();
                        System.out.print("Enter Project ID: ");
                        int taskProjId = scanner.nextInt();
                        System.out.print("Enter Employee ID: ");
                        int taskEmpId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter Status (Assigned/started/completed): ");
                        String taskStatus = scanner.nextLine();

                        Task task = new Task(taskId, taskName, taskProjId, taskEmpId, taskStatus);
                        boolean taskAdded = repo.createTask(task);
                        System.out.println("Task added: " + taskAdded);
                        break;

                    case 4:
                        // Assign Project to Employee
                        System.out.print("Enter Project ID: ");
                        int assignProjId = scanner.nextInt();
                        System.out.print("Enter Employee ID: ");
                        int assignEmpId = scanner.nextInt();
                        repo.assignProjectToEmployee(assignProjId, assignEmpId);
                        System.out.println("Project assigned to employee");
                        break;

                    case 5:
                        // Assign Task to Employee
                        System.out.print("Enter Task ID: ");
                        int assignTaskId = scanner.nextInt();
                        System.out.print("Enter Project ID: ");
                        int assignTaskProjId = scanner.nextInt();
                        System.out.print("Enter Employee ID: ");
                        int assignTaskEmpId = scanner.nextInt();
                        repo.assignTaskInProjectToEmployee(assignTaskId, assignTaskProjId, assignTaskEmpId);
                        System.out.println("Task assigned to employee");
                        break;

                    case 6:
                        // Delete Employee
                        System.out.print("Enter Employee ID to delete: ");
                        int deleteEmpId = scanner.nextInt();
                        repo.deleteEmployee(deleteEmpId);
                        System.out.println("Employee deleted");
                        break;

                    case 7:
                        // Delete Project
                        System.out.print("Enter Project ID to delete: ");
                        int deleteProjId = scanner.nextInt();
                        repo.deleteProject(deleteProjId);
                        System.out.println("Project deleted");
                        break;

                    case 8:
                        // List All Tasks
                        System.out.print("Enter Employee ID: ");
                        int listEmpId = scanner.nextInt();
                        System.out.print("Enter Project ID: ");
                        int listProjId = scanner.nextInt();
                        List<Task> tasks = repo.getAllTasks(listEmpId, listProjId);
                        tasks.forEach(t -> System.out.println(t.getTaskName()));
                        break;

                    case 9:
                        System.out.println("Exiting...");
                        DBConnUtil.closeConnection();
                        scanner.close();
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice");
                }
            } catch (EmployeeNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (ProjectNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
                scanner.nextLine(); // Clear input buffer in case of exception
            }
        }
    }
}