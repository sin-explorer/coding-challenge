package Test1;

import dao.ProjectRepositoryImpl;
import entity.Employee;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.sql.Connection;
import java.sql.Statement;
import static org.junit.jupiter.api.Assertions.*;

public class TestCreateEmployee {
    private ProjectRepositoryImpl repo;
    private Connection conn;
    private Statement stmt;

    @BeforeEach
    void setUp() throws Exception {
        repo = new ProjectRepositoryImpl();
        conn = util.DBConnUtil.getConnection();
        stmt = conn.createStatement();
        // No DELETE, assuming unique IDs
    }

    @AfterEach
    void tearDown() throws Exception {
        if (stmt != null) stmt.close();
        // conn.close() is not called to keep the static connection open
    }

    @Test
    void testCreateEmployeeSuccessfully() throws Exception {
        Employee emp = new Employee(2, "Sham", "Tester", "F", 60000.00, 0); // Unique ID 2
        boolean result = repo.createEmployee(emp);
        assertTrue(result, "Employee should be created successfully");
    }
}