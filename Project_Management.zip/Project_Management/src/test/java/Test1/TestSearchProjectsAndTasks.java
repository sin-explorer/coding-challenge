package Test1;


import dao.ProjectRepositoryImpl;
import entity.Task;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class TestSearchProjectsAndTasks {
    private ProjectRepositoryImpl repo;
    private Connection conn;
    private Statement stmt;

    @BeforeEach
    void setUp() throws Exception {
        repo = new ProjectRepositoryImpl();
        conn = util.DBConnUtil.getConnection();
        stmt = conn.createStatement();
        // No DELETE, insert sample data with unique IDs
        stmt.executeUpdate("INSERT INTO Employee (id, name, designation, gender, salary, project_id) VALUES (11, 'Jane Doe', 'Tester', 'F', 60000.00, 2)");
        stmt.executeUpdate("INSERT INTO Project (id, projectName, description, start_date, status) VALUES (4, 'CRM System', 'Test Project', '2023-10-02', 'started')");
        stmt.executeUpdate("INSERT INTO Task (task_id, task_name, project_id, employee_id, status) VALUES (5, 'Test Task 2', 4, 10, 'Assigned')");
    }

    @AfterEach
    void tearDown() throws Exception {
        if (stmt != null) stmt.close();
        // conn.close() is not called to keep the static connection open
    }

    @Test
    void testSearchProjectsAndTasksAssignedToEmployee() throws Exception {
        List tasks = repo.getAllTasks(2, 2);
        assertFalse(tasks.isEmpty(), "Should find at least one task assigned to employee");
    }
}