package Test1;

import dao.ProjectRepositoryImpl;
import entity.Task;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.sql.Connection;
import java.sql.Statement;
import static org.junit.jupiter.api.Assertions.*;

public class TestCreateTask {
    private ProjectRepositoryImpl repo;
    private Connection conn;
    private Statement stmt;

    @BeforeEach
    void setUp() throws Exception {
        repo = new ProjectRepositoryImpl();
        conn = util.DBConnUtil.getConnection();
        stmt = conn.createStatement();
        // No DELETE, insert prerequisite data with unique IDs
        stmt.executeUpdate("INSERT INTO Employee (id, name, designation, gender, salary, project_id) VALUES (4, 'Soham', 'Developement', 'M', 60000.00, 0)");
        stmt.executeUpdate("INSERT INTO Project (id, projectName, description, start_date, status) VALUES (2, 'ER Developer', 'Test Project', '2023-10-02', 'started')");
    }

    @AfterEach
    void tearDown() throws Exception {
        if (stmt != null) stmt.close();
        // conn.close() is not called to keep the static connection open
    }

    @Test
    void testCreateTaskSuccessfully() throws Exception {
        Task task = new Task(2, "Test Task 2", 2, 2, "Assigned"); // Unique ID 2
        boolean result = repo.createTask(task);
        assertTrue(result, "Task should be created successfully");
    }
}