package org.example;

import main.ProjectApp; // Adjust package if different
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import static org.junit.jupiter.api.Assertions.*;

public class AppTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private ProjectApp app;

    @BeforeEach
    void setUp() {
        System.setOut(new PrintStream(outContent));
        app = new ProjectApp(); // Assuming ProjectApp has a constructor or static method to test
    }

    @AfterEach
    void tearDown() {
        System.setOut(originalOut);
    }

    @Test
    void testAppMenuDisplay() {
        // Simulate user input (e.g., entering '9' to exit)
        String input = "9\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        app.main(new String[]{});
        assertTrue(outContent.toString().contains("=== Project Management System ==="), "Menu should be displayed");
    }
}