CREATE DATABASE IF NOT EXISTS project_management;
USE project_management;
CREATE TABLE Employee (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    designation VARCHAR(50) NOT NULL,
    gender CHAR(1) CHECK (gender IN ('M', 'F')),
    salary DECIMAL(10, 2) NOT NULL,
    project_id INT DEFAULT 0
);

CREATE TABLE Project (
    id INT PRIMARY KEY,
    projectName VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    start_date DATE NOT NULL,
    status VARCHAR(20) CHECK (status IN ('started', 'dev', 'build', 'test', 'deployed'))
);

CREATE TABLE Task (
    task_id INT PRIMARY KEY,
    task_name VARCHAR(100) NOT NULL,
    project_id INT NOT NULL,
    employee_id INT NOT NULL,
    status VARCHAR(20) CHECK (status IN ('Assigned', 'started', 'completed'))
);


INSERT INTO Employee (id, name, designation, gender, salary, project_id) VALUES
(1, 'John Doe', 'Developer', 'M', 50000.00, 0),
(2, 'Jane Doe', 'Tester', 'F', 60000.00, 0),
(3, 'Mike Smith', 'Project Manager', 'M', 75000.00, 0);

INSERT INTO Project (id, projectName, description, start_date, status) VALUES
(1, 'ERP System', 'Enterprise Resource Planning Software', '2023-10-01', 'started'),
(2, 'CRM Platform', 'Customer Relationship Management Tool', '2023-11-15', 'dev');


INSERT INTO Task (task_id, task_name, project_id, employee_id, status) VALUES
(1, 'Design UI', 1, 1, 'Assigned'),
(2, 'Test API', 1, 2, 'Assigned'),
(3, 'Develop Backend', 2, 3, 'started'),
(4, 'Deploy Application', 2, 1, 'Assigned');



select * from task;
