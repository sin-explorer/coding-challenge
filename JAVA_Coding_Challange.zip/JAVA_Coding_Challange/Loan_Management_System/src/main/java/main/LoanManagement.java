package main;

import dao.ILoanRepository;
import dao.ILoanRepositoryImpl;
import entity.*;
import exception.InvalidLoanException;
import java.util.Scanner;
import java.util.List;

public class LoanManagement {
    public static void main(String[] args) {
        ILoanRepository repo = new ILoanRepositoryImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nLoan Management System Menu:");
            System.out.println("1. Apply Loan");
            System.out.println("2. Get All Loans");
            System.out.println("3. Get Loan by ID");
            System.out.println("4. Loan Repayment");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline
            int loanId = 0; // Declare loanId outside the switch to avoid scope issues

            try {
                switch (choice) {
                    case 1:
                        Customer customer = new Customer(1, "John Doe", "john@example.com", "1234567890",
                                "123 Main St", 700);
                        HomeLoan homeLoan = new HomeLoan(0, customer, 100000, 5.0, 24, "Pending",
                                "456 Oak St", 150000);
                        repo.applyLoan(homeLoan);
                        repo.loanStatus(homeLoan.getLoanId());
                        System.out.println("Interest: " + repo.calculateInterest(homeLoan.getLoanId()));
                        System.out.println("EMI: " + repo.calculateEMI(homeLoan.getLoanId()));
                        break;

                    case 2:
                        List<Loan> loans = repo.getAllLoan(); // Line 41
                        for (Loan loan : loans) { // Use traditional for-each loop
                            loan.printInfo();
                        }
                        break;

                    case 3:
                        System.out.print("Enter Loan ID: ");
                        loanId = sc.nextInt();
                        repo.getLoanById(loanId);
                        break;

                    case 4:
                        System.out.print("Enter Loan ID: ");
                        loanId = sc.nextInt();
                        System.out.print("Enter Amount: ");
                        double amount = sc.nextDouble();
                        repo.loanRepayment(loanId, amount);
                        break;

                    case 5:
                        System.out.println("Exiting...");
                        sc.close();
                        return;

                    default:
                        System.out.println("Invalid choice");
                }
            } catch (InvalidLoanException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }
    }
}