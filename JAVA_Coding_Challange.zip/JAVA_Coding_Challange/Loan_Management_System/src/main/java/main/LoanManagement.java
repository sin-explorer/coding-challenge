package main;

import dao.ILoanRepository;
import dao.ILoanRepositoryImpl;
import entity.*;
import exception.InvalidLoanException;
import java.util.Scanner;
import java.util.List;

public class LoanManagement {
    public static void main(String[] args) {
        ILoanRepository repo = new ILoanRepositoryImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nLoan Management System Menu:");
            System.out.println("1. Apply Loan");
            System.out.println("2. Get All Loans");
            System.out.println("3. Get Loan by ID");
            System.out.println("4. Loan Repayment");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline
            int loanId = 0; // Declare loanId outside the switch to avoid scope issues

            try {
                switch (choice) {
                    case 1:
                        // Input customer details
                        System.out.print("Enter Customer ID: ");
                        int customerId = sc.nextInt();
                        sc.nextLine(); // Consume newline
                        System.out.print("Enter Name: ");
                        String name = sc.nextLine();
                        System.out.print("Enter Email Address: ");
                        String email = sc.nextLine();
                        System.out.print("Enter Phone Number: ");
                        String phone = sc.nextLine();
                        System.out.print("Enter Address: ");
                        String address = sc.nextLine();
                        System.out.print("Enter Credit Score: ");
                        int creditScore = sc.nextInt();
                        sc.nextLine(); // Consume newline

                        Customer customer = new Customer(customerId, name, email, phone, address, creditScore);

                        // Input loan details
                        System.out.print("Enter Principal Amount: ");
                        double principal = sc.nextDouble();
                        System.out.print("Enter Interest Rate (%): ");
                        double interestRate = sc.nextDouble();
                        System.out.print("Enter Loan Term (months): ");
                        int loanTerm = sc.nextInt();
                        sc.nextLine(); // Consume newline
                        System.out.print("Enter Loan Type (HomeLoan/CarLoan): ");
                        String loanType = sc.nextLine();
                        Loan loan;
                        if ("HomeLoan".equalsIgnoreCase(loanType)) {
                            System.out.print("Enter Property Address: ");
                            String propAddress = sc.nextLine();
                            System.out.print("Enter Property Value: ");
                            double propValue = sc.nextDouble();
                            loan = new HomeLoan(0, customer, principal, interestRate, loanTerm, "Pending", propAddress, propValue);
                        } else if ("CarLoan".equalsIgnoreCase(loanType)) {
                            System.out.print("Enter Car Model: ");
                            String carModel = sc.nextLine();
                            System.out.print("Enter Car Value: ");
                            double carValue = sc.nextDouble();
                            loan = new CarLoan(0, customer, principal, interestRate, loanTerm, "Pending", carModel, carValue);
                        } else {
                            System.out.println("Invalid loan type. Defaulting to HomeLoan.");
                            loan = new HomeLoan(0, customer, principal, interestRate, loanTerm, "Pending", "N/A", 0.0);
                        }

                        repo.applyLoan(loan);
                        repo.loanStatus(loan.getLoanId());
                        // Refresh the loan object to get the updated status
                        loan = repo.getLoanById(loan.getLoanId()); // Update loan with database state
                        // Check loan
                        if ("Approved".equals(loan.getLoanStatus())) {
                            System.out.println("Interest: " + repo.calculateInterest(loan.getLoanId()));
                            System.out.println("EMI: " + repo.calculateEMI(loan.getLoanId()));
                        } else {
                            System.out.println("Loan is rejected. Interest and EMI calculations are not applicable.");
                        }
                        break;

                    case 2:
                        List<Loan> loans = repo.getAllLoan();
                        for (Loan l : loans) {
                            l.printInfo();
                        }
                        break;

                    case 3:
                        System.out.print("Enter Loan ID: ");
                        loanId = sc.nextInt();
                        Loan retrievedLoan = repo.getLoanById(loanId); // Assign the returned Loan object
                        retrievedLoan.printInfo(); // Print the loan details
                        break;

                    case 4:
                        System.out.print("Enter Loan ID: ");
                        loanId = sc.nextInt();
                        System.out.print("Enter Amount: ");
                        double amount = sc.nextDouble();
                        repo.loanRepayment(loanId, amount);
                        break;

                    case 5:
                        System.out.println("Exiting...");
                        sc.close();
                        return;

                    default:
                        System.out.println("Invalid choice");
                }
            } catch (InvalidLoanException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }
    }
}