package dao;

import entity.*;
import exception.InvalidLoanException;
import util.DBConnUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ILoanRepositoryImpl implements ILoanRepository {
    private Connection conn;

    public ILoanRepositoryImpl() {
        conn = DBConnUtil.getConnection();
    }

    @Override
    public void applyLoan(Loan loan) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.print("Confirm loan application (Yes/No): ");
        String confirm = sc.nextLine();
        if (!confirm.equalsIgnoreCase("Yes")) return;

        // Start transaction
        conn.setAutoCommit(false);

        try {
            // Insert Customer if not exists
            Customer customer = loan.getCustomer();
            String checkCustomerSql = "SELECT customer_id FROM customer WHERE customer_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkCustomerSql);
            checkStmt.setInt(1, customer.getCustomerId());
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next()) {
                String insertCustomerSql = "INSERT INTO customer (customer_id, name, email_address, phone_number, address, credit_score) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement pstmtCustomer = conn.prepareStatement(insertCustomerSql)) {
                    pstmtCustomer.setInt(1, customer.getCustomerId());
                    pstmtCustomer.setString(2, customer.getName());
                    pstmtCustomer.setString(3, customer.getEmailAddress());
                    pstmtCustomer.setString(4, customer.getPhoneNumber());
                    pstmtCustomer.setString(5, customer.getAddress());
                    pstmtCustomer.setInt(6, customer.getCreditScore());
                    pstmtCustomer.executeUpdate();
                }
            }

            // Insert Loan
            String sql = "INSERT INTO loan (customer_id, principal_amount, interest_rate, loan_term, loan_type, loan_status, " +
                    "property_address, property_value, car_model, car_value) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setInt(1, loan.getCustomer().getCustomerId());
                pstmt.setDouble(2, loan.getPrincipalAmount());
                pstmt.setDouble(3, loan.getInterestRate());
                pstmt.setInt(4, loan.getLoanTerm());
                pstmt.setString(5, loan.getLoanType());
                pstmt.setString(6, loan.getLoanStatus());
                if (loan instanceof HomeLoan) {
                    pstmt.setString(7, ((HomeLoan) loan).getPropertyAddress());
                    pstmt.setDouble(8, ((HomeLoan) loan).getPropertyValue());
                    pstmt.setNull(9, Types.VARCHAR);
                    pstmt.setNull(10, Types.DECIMAL);
                } else if (loan instanceof CarLoan) {
                    pstmt.setNull(7, Types.VARCHAR);
                    pstmt.setNull(8, Types.DECIMAL);
                    pstmt.setString(9, ((CarLoan) loan).getCarModel());
                    pstmt.setDouble(10, ((CarLoan) loan).getCarValue());
                }
                pstmt.executeUpdate();
                ResultSet rsLoan = pstmt.getGeneratedKeys();
                if (rsLoan.next()) {
                    loan.setLoanId(rsLoan.getInt(1));
                }
            }

            // Commit transaction
            conn.commit();
            System.out.println("Loan application successful. Loan ID: " + loan.getLoanId());

        } catch (SQLException e) {
            // Rollback transaction on error
            conn.rollback();
            throw new Exception("Failed to apply loan: " + e.getMessage());
        } finally {
            conn.setAutoCommit(true);
        }
    }

    @Override
    public double calculateInterest(int loanId) throws InvalidLoanException {
        Loan loan = getLoanFromDB(loanId);
        return calculateInterest(loan.getPrincipalAmount(), loan.getInterestRate(), loan.getLoanTerm());
    }

    @Override
    public double calculateInterest(double principalAmount, double interestRate, int loanTerm) {
        return principalAmount * (interestRate / 100) * (loanTerm / 12.0); // Corrected for annual interest
    }

    @Override
    public void loanStatus(int loanId) throws InvalidLoanException {
        Loan loan = getLoanFromDB(loanId);
        Scanner sc = new Scanner(System.in);
        System.out.print("Approve loan? (Yes/No, or enter 'auto' for automatic approval based on credit score): ");
        String decision = sc.nextLine().trim().toLowerCase();

        String newStatus;
        if ("auto".equals(decision)) {
            newStatus = loan.getCustomer().getCreditScore() > 650 ? "Approved" : "Rejected";
        } else if ("yes".equals(decision)) {
            newStatus = "Approved";
        } else if ("no".equals(decision)) {
            newStatus = "Rejected";
        } else {
            System.out.println("Invalid input. Using automatic decision.");
            newStatus = loan.getCustomer().getCreditScore() > 650 ? "Approved" : "Rejected";
        }

        loan.setLoanStatus(newStatus);
        String sql = "UPDATE loan SET loan_status = ? WHERE loan_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, loanId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new InvalidLoanException("Failed to update loan status");
        }
        System.out.println("Loan Status updated to: " + newStatus);
    }

    @Override
    public double calculateEMI(int loanId) throws InvalidLoanException {
        Loan loan = getLoanFromDB(loanId);
        return calculateEMI(loan.getPrincipalAmount(), loan.getInterestRate() / 12 / 100, loan.getLoanTerm());
    }

    @Override
    public double calculateEMI(double principalAmount, double monthlyInterestRate, int loanTerm) {
        if (monthlyInterestRate == 0) return principalAmount / loanTerm; // Handle zero interest
        double emi = (principalAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, loanTerm)) /
                (Math.pow(1 + monthlyInterestRate, loanTerm) - 1);
        return emi;
    }

    @Override
    public void loanRepayment(int loanId, double amount) throws InvalidLoanException {
        Loan loan = getLoanFromDB(loanId);
        double emi = calculateEMI(loanId);
        if (amount < emi) {
            throw new InvalidLoanException("Payment amount less than EMI");
        }
        int noOfEmi = (int) (amount / emi);
        System.out.println("Number of EMIs paid: " + noOfEmi);
        // Update logic can be added here
    }

    @Override
    public List<Loan> getAllLoan() {
        List<Loan> loans = new ArrayList<>();
        String sql = "SELECT l.*, c.* FROM loan l JOIN customer c ON l.customer_id = c.customer_id";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                loans.add(mapResultSetToLoan(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return loans;
    }

    @Override
    public Loan getLoanById(int loanId) throws InvalidLoanException {
        return getLoanFromDB(loanId);
    }

    private Loan getLoanFromDB(int loanId) throws InvalidLoanException {
        String sql = "SELECT l.*, c.* FROM loan l JOIN customer c ON l.customer_id = c.customer_id WHERE l.loan_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, loanId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToLoan(rs);
            } else {
                throw new InvalidLoanException("Loan not found with ID: " + loanId);
            }
        } catch (SQLException e) {
            throw new InvalidLoanException("Database error: " + e.getMessage());
        }
    }

    private Loan mapResultSetToLoan(ResultSet rs) throws SQLException {
        Customer customer = new Customer(
                rs.getInt("customer_id"),
                rs.getString("name"),
                rs.getString("email_address"),
                rs.getString("phone_number"),
                rs.getString("address"),
                rs.getInt("credit_score")
        );

        Loan loan;
        if ("HomeLoan".equals(rs.getString("loan_type"))) {
            loan = new HomeLoan(
                    rs.getInt("loan_id"),
                    customer,
                    rs.getDouble("principal_amount"),
                    rs.getDouble("interest_rate"),
                    rs.getInt("loan_term"),
                    rs.getString("loan_status"),
                    rs.getString("property_address"),
                    rs.getDouble("property_value")
            );
        } else {
            loan = new CarLoan(
                    rs.getInt("loan_id"),
                    customer,
                    rs.getDouble("principal_amount"),
                    rs.getDouble("interest_rate"),
                    rs.getInt("loan_term"),
                    rs.getString("loan_status"),
                    rs.getString("car_model"),
                    rs.getDouble("car_value")
            );
        }
        return loan;
    }
}