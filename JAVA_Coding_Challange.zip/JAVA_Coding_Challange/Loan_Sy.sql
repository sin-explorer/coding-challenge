CREATE DATABASE LoanManagementSystem;
USE LoanManagementSystem;

-- Create Customer Table
CREATE TABLE customer (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email_address VARCHAR(100) UNIQUE NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    address TEXT NOT NULL,
    credit_score INT NOT NULL
);

-- Create Loan Table
CREATE TABLE loan (
    loan_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    principal_amount DECIMAL(15,2) NOT NULL,
    interest_rate DECIMAL(5,2) NOT NULL,
    loan_term INT NOT NULL,
    loan_type ENUM('CarLoan', 'HomeLoan') NOT NULL,
    loan_status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    property_address TEXT,  -- For HomeLoan
    property_value DECIMAL(15,2),  -- For HomeLoan
    car_model VARCHAR(100),  -- For CarLoan
    car_value DECIMAL(15,2),  -- For CarLoan
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
);

select *from loan;